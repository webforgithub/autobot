<strong>Dear trader</strong>, <br /><br />
Autobot posted one order with following order detail.<br /><br />
<strong>Trade Type:</strong><?php echo e($data->orderObject["type"]); ?><br />
<strong>Client Order Id:</strong> <?php echo e($data->orderObject["clientOrderId"]); ?><br />
<strong>Order Id:</strong> <?php echo e($data->orderObject["orderId"]); ?><br />
<strong>Crypto Currency:</strong> <?php echo e($data->orderObject["symbol"]); ?><br />
<strong>Trade Quantity:</strong> <?php echo e($data->orderObject["executedQty"]); ?><br />
<strong>Trade Price:</strong> <?php echo e($data->orderObject["price"]); ?><br />

<strong>Thanks</strong> ,<br />
CryptoBee