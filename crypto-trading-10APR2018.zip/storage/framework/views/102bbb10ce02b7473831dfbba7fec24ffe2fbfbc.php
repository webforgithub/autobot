<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo e(LAConfigs::getByKey('site_description')); ?>">
    <meta name="author" content="Dwij IT Solutions">

    <meta property="og:title" content="<?php echo e(LAConfigs::getByKey('sitename')); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:description" content="<?php echo e(LAConfigs::getByKey('site_description')); ?>" />
    
    <meta property="og:url" content="" />
    <meta property="og:sitename" content="" />
    <meta property="og:image" content="" />
    
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="" />
    <meta name="twitter:creator" content="" />
    
    <title><?php echo e(LAConfigs::getByKey('sitename')); ?></title>
    
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('/la-assets/css/bootstrap.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('la-assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('/la-assets/css/main.css')); ?>" rel="stylesheet">

    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,300,700' rel='stylesheet' type='text/css'>

    <script src="<?php echo e(asset('/la-assets/plugins/jQuery/jQuery-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/la-assets/js/smoothscroll.js')); ?>"></script>


</head>

<body data-spy="scroll" data-offset="0" data-target="#navigation">

<!-- Fixed navbar -->
<div id="navigation" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"><b><?php echo e(LAConfigs::getByKey('sitename')); ?></b></a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="#home" class="smoothScroll">Home</a></li>
                <li><a href="#about" class="smoothScroll">About</a></li>
                <li><a href="#contact" class="smoothScroll">Contact</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <!--<li><a href="<?php echo e(url('/register')); ?>">Register</a></li>-->
                <?php else: ?>
                    <li><a href="<?php echo e(url(config('laraadmin.adminRoute'))); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                <?php endif; ?>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>


<section id="home" name="home"></section>
<div id="headerwrap">
    <div class="container">
        <div class="row centered">
            <div class="col-lg-12">
                <h1><img src="/la-assets/img/crypto-bee-logo.jpg" /></h1>
                <h1><?php echo e(LAConfigs::getByKey('sitename_part1')); ?> <b><a><?php echo e(LAConfigs::getByKey('sitename_part2')); ?></a></b></h1>
                <h3><?php echo e(LAConfigs::getByKey('site_description')); ?></h3>
                <h3><a href="<?php echo e(url('/login')); ?>" class="btn btn-lg btn-success">Get Started!</a></h3><br>
            </div>            
        </div>
    </div> <!--/ .container -->
</div><!--/ #headerwrap -->

<div id="c">
    <div class="container">
        <p>
            <strong>Copyright &copy; 2018.</a>
        </p>
    </div>
</div>


<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo e(asset('/la-assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script>
    $('.carousel').carousel({
        interval: 3500
    })
</script>
</body>
</html>
