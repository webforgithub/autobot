<?php $__env->startSection("contentheader_title"); ?>
	<a href="<?php echo e(url(config('laraadmin.adminRoute') . '/configuremacdbots')); ?>">ConfigureMACDBot</a> :
<?php $__env->stopSection(); ?>
<?php $__env->startSection("contentheader_description", $configuremacdbot->$view_col); ?>
<?php $__env->startSection("section", "ConfigureMACDBots"); ?>
<?php $__env->startSection("section_url", url(config('laraadmin.adminRoute') . '/configuremacdbots')); ?>
<?php $__env->startSection("sub_section", "Edit"); ?>

<?php $__env->startSection("htmlheader_title", "ConfigureMACDBots Edit : ".$configuremacdbot->$view_col); ?>

<?php $__env->startSection("main-content"); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="box">
	<div class="box-header">
		
	</div>
	<div class="box-body">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<?php echo Form::model($configuremacdbot, ['route' => [config('laraadmin.adminRoute') . '.configuremacdbots.update', $configuremacdbot->id ], 'method'=>'PUT', 'id' => 'configuremacdbot-edit-form']); ?>

					<?php /*<?php echo LAFormMaker::form($module); ?>*/ ?>
                                        <div class="form-group">
                                            <label for="symbol">Trade Symbol* :</label>
                                            <select id="symbol" name="symbol" class="form-control select2-hidden-accessible" required="1" data-placeholder="Enter Trade Symbol" rel="select2" name="dept" tabindex="-1" aria-hidden="true" aria-required="true">
                                            <?php foreach( $symbols as $col ): ?>
                                            <option <?php echo e($module->row->symbol == $col->col ? 'selected="selected"' : ""); ?>  values='<?php echo e(strtoupper($col->col)); ?>'><?php echo e(strtoupper($col->col)); ?></option>
                                            <?php endforeach; ?>
                                            </select>
                                        </div>
					<?php echo LAFormMaker::input($module, 'alert_email'); ?>
					<?php echo LAFormMaker::input($module, 'alert_mobile'); ?>
					<?php echo LAFormMaker::input($module, 'volume'); ?>
					<?php echo LAFormMaker::input($module, 'totalorder'); ?>
					<?php echo LAFormMaker::input($module, 'period'); ?>
					<?php echo LAFormMaker::input($module, 'period_length'); ?>
					<?php echo LAFormMaker::input($module, 'min_periods'); ?>
					<?php echo LAFormMaker::input($module, 'ema_short_period'); ?>
					<?php echo LAFormMaker::input($module, 'ema_long_period'); ?>
					<?php echo LAFormMaker::input($module, 'signal_period'); ?>
					<?php echo LAFormMaker::input($module, 'up_trend_threshold'); ?>
					<?php echo LAFormMaker::input($module, 'down_trend_threshold'); ?>
					<?php echo LAFormMaker::input($module, 'overbought_periods'); ?>
					<?php echo LAFormMaker::input($module, 'overbought_rsi'); ?>
					<?php echo LAFormMaker::input($module, 'use_all_fund'); ?>
                                        <input type="hidden" name="userid" id="userid" />
					
					<?php /*
					<?php echo LAFormMaker::input($module, 'symbol'); ?>
					<?php echo LAFormMaker::input($module, 'userid'); ?>
					<?php echo LAFormMaker::input($module, 'alert_email'); ?>
					<?php echo LAFormMaker::input($module, 'alert_mobile'); ?>
					<?php echo LAFormMaker::input($module, 'volume'); ?>
					<?php echo LAFormMaker::input($module, 'totalorder'); ?>
					<?php echo LAFormMaker::input($module, 'period'); ?>
					<?php echo LAFormMaker::input($module, 'period_length'); ?>
					<?php echo LAFormMaker::input($module, 'min_periods'); ?>
					<?php echo LAFormMaker::input($module, 'ema_short_period'); ?>
					<?php echo LAFormMaker::input($module, 'ema_long_period'); ?>
					<?php echo LAFormMaker::input($module, 'signal_period'); ?>
					<?php echo LAFormMaker::input($module, 'up_trend_threshold'); ?>
					<?php echo LAFormMaker::input($module, 'down_trend_threshold'); ?>
					<?php echo LAFormMaker::input($module, 'overbought_periods'); ?>
					<?php echo LAFormMaker::input($module, 'overbought_rsi'); ?>
					<?php echo LAFormMaker::input($module, 'use_all_fund'); ?>
					*/ ?>
                    <br>
					<div class="form-group">
						<?php echo Form::submit( 'Update', ['class'=>'btn btn-success']); ?> <button class="btn btn-default pull-right"><a href="<?php echo e(url(config('laraadmin.adminRoute') . '/configuremacdbots')); ?>">Cancel</a></button>
					</div>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
	$("#configuremacdbot-edit-form").validate({
		
	});
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("la.layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>