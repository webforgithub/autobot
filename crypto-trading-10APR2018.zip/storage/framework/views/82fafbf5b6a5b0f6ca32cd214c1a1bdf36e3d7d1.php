<?php $__env->startSection("contentheader_title", "Binance"); ?>
<?php $__env->startSection("contentheader_description", "My Account"); ?>
<?php $__env->startSection("section", "Binance Settings"); ?>
<?php $__env->startSection("sub_section", "Listing"); ?>
<?php $__env->startSection("htmlheader_title", "My account"); ?>

<?php $__env->startSection("main-content"); ?>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php foreach($errors->all() as $error): ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<div class="box box-success">
    <!--<div class="box-header"></div>-->
    <div class="box-body">
        <div class="row">
            <div class="col-md-12">
                <table id="tblTicker" class="table table-bordered">
                    <thead>
                        <tr class="success">
                            <?php foreach( $listing_cols as $col ): ?>
                            <th><?php echo e(ucfirst($col)); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>                
                        <?php foreach( $myAccount['balances'] as $key => $col ): ?>
                        <?php if($col["free"] > 0): ?>
                        <tr>
                            <td class="tdFirst" data-tokenPair='<?php echo e(ucfirst($key)); ?>'><?php echo e(ucfirst($col["asset"])); ?></td>
                            <td class="tdSecond"><?php echo e($col["free"]); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; ?>                
                    </tbody>
                </table>
            </div>
        </div>
    </div>        
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('la-assets/plugins/datatables/datatables.min.css')); ?>"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('la-assets/plugins/datatables/datatables.min.js')); ?>"></script>
<script>
$(function () {
    $('#btnOrderBuy').on('click', function () {
        $("#dvMessage").removeClass('alert alert-success').html('');
        $.ajax({
            type: "POST",
            headers: {'X-CSRF-TOKEN': token},
            url: $('#frmOrder').attr('action'),
            data: $("#frmOrder").serialise(),            
            success: function (data) {
                $("#dvMessage").addClass('alert alert-success').append(data.data + "<br />");
            },
            error: function (data) {                
            }
        });
    });
    $('#btnOrderSell').on('click', function () {
        alert('hello');
    });

    $('#tblTicker tbody tr').on('click', function () {
        var tokenPair = $(this).find('td:tdFirst').attr('data-tokenPair');
        var tokenPrice = $(this).find('td.tdSecond').attr('data-tokenPrice');

        alert(tokenPair + " " + tokenPrice);
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("la.layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>